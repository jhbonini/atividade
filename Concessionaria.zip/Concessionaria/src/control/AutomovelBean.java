
package control;
import java.util.ArrayList;

import javax.faces.bean.ManagedBean;
@ManagedBean

public class AutomovelBean {
	private ArrayList<String>tipos;
	private ArrayList<String>servicos;
	private String tipo;
	private String servico;
	
	public AutomovelBean() {
		tipos = new ArrayList<String>();
		tipos.add("Autom�vel");
		tipos.add("moto");
		servicos = new ArrayList<String>();
		servicos.add("Troca de pneus");
		servicos.add("Troca de �leo");
		servicos.add("Troca de pastilhas de freio");
		servicos.add("Inje��o eletr�nica");
		servicos.add("Reparo em motores");
		servicos.add("Sistema el�trico");
		servicos.add("Suspens�o");
	}
	public ArrayList<String> getTipos(){
		return tipos;
	}
	public void setTipos(String tipo){
	tipos.add(tipo);
	}
	public ArrayList<String> getservicos(){
		return servicos;
	}
	public void setServicos(String servico){
		servicos.add(servico);
	}
	
}
