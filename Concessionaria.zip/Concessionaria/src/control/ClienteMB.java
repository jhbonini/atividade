package control;

import model.Cliente;

public class ClienteMB {
	Cliente c = new Cliente();
	
	public ClienteMB() {
	}
	
	public void setNome(String nome) {
		c.setNome(nome);
		}
		public String getNome() {
		return c.getNome();
		}
		
		public void setIdade(String idade) {
			c.setIdade(idade);
			}
			public String getIdade() {
			return c.getIdade();
			}
			
			public void setCpf(String cpf) {
				c.setCpf(cpf);
				}
				public String getCpf() {
				return c.getCpf();
				}
				
	
				public void setRua(String rua) {
				c.setRua(rua);
				}
				public String getRua() {
				return c.getRua();
				}
				
		
				public void setCidade(String cidade) {
				c.setCidade(cidade);
				}
				public String getCidade() {
				return c.getCidade();
				}
				
				
				public void setEndere�o(String endere�o) {
					c.setEndere�o(endere�o);
					}
					public String getEndere�o() {
					return c.getEndere�o();
					}
					
					public void setTelefone(String telefone) {
						c.setTelefone(telefone);
						}
						public String getTelefone() {
						return c.getTelefone();
						}
						
						public void setEmail(String email) {
							c.setEmail(email);
							}
							public String getEmail() {
							return c.getEmail();
							}

}
