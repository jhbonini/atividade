package model;

public class Cliente {
	private String nome;
	private String idade;
	private String cpf;
	private String rua;
	private String cidade;
	private String endere�o;
	private String email;
	private String telefone;
	
	public String getNome() {
		return nome ;
	}
	public void setNome(String nome ) {
		this.nome = nome ;
	}
	
	public String getIdade() {
		return idade;
	}
	public void setIdade(String idade ) {
		this.idade = idade;
	}

	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	public String getRua() {
		return rua;
		}
		public void setRua(String rua) {
		this.rua = rua;
		}
		public String getCidade() {
		return cidade;
		}
		public void setCidade(String cidade) {
		this.cidade = cidade;
		}

	public String getEndere�o() {
		return endere�o;
	}
	public void setEndere�o(String endere�o) {
		this.endere�o = endere�o;
	}

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

}
